#!sh
iptables --list --table filter
iptables --list --table mangle
iptables --list --table nat

